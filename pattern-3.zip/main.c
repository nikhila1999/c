/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int
main ()
{
  int i, j, k, s=1;
  for (i = 5; i >= 1; i--)
    {
      for (j = 1; j <=s; j++)
	{
	  printf (" ");
	}
      for (k = 1; k <= i; k++)
	{
	  printf (" * ");
	}
	s= s+1;
      printf ("\n");
    }
  getch ();
}

