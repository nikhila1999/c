/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<conio.h>
void main()
{
    int rw,c,no=1,len;
    printf("enter number of rows:");
    scanf("%d",&len);
    for(rw=1;rw<=len;rw++){
        printf("\n");
        for(c=1;c<=rw;c++){
            printf("%2d",no);
            no++;
        }
    }
            
}
